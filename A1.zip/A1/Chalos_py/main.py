import sounddevice
import threading
import time
import serial
import numpy as np


# Open the serial port for communication with Arduino
ser = serial.Serial('/dev/cu.usbmodem141101', 9600)  # Replace 'COMx' with your Arduino's COM port

def generate_tone(frequency):
    duration = 0.35  # Adjust this value to change the total duration of the continuous beep
    t = np.arange(int(44100 * duration)) / 44100.0
    waveform = 0.5 * np.sin(2 * np.pi * frequency * t)
    return (waveform * 52767).astype(np.int16)


def beep_thread():
    while True:
        current_frequency = get_humidity_as_frequency()
        beep = generate_tone(current_frequency)
        sounddevice.play(beep, samplerate=44100, blocking=True)


def input_thread():
    while True:
        new_frequency = input("Enter new frequency (0 to exit): ")
        if new_frequency == '0':
            break
        try:
            set_frequency(int(new_frequency))
        except ValueError:
            print("Invalid input. Please enter a valid integer.")


def get_humidity_as_frequency():
    # Read humidity value from Arduino
    humidity_value = ser.readline().decode('utf-8').strip()

    # Convert humidity value to a frequency range (adjust as needed)
    frequency_range = (10, 1000)  # You can adjust this range based on your humidity values
    humidity_as_frequency = float(humidity_value) % (frequency_range[1] - frequency_range[0]) + frequency_range[0]
    humidity_as_frequency = min(humidity_as_frequency * 2 + 50, 238)
    print(humidity_as_frequency)

    return humidity_as_frequency


def set_frequency(new_frequency):
    with frequency_lock:
        global frequency
        frequency = new_frequency


if __name__ == "__main__":
    # Default frequency
    frequency = 440  # You can change this to your preferred starting frequency

    # Lock for synchronizing access to the frequency variable
    frequency_lock = threading.Lock()

    # Start the continuous beep thread
    beep_thread = threading.Thread(target=beep_thread)
    beep_thread.start()

    # Start the input thread
    input_thread = threading.Thread(target=input_thread)
    input_thread.start()

    try:
        # Wait for input thread to finish
        input_thread.join()
    finally:
        # Stop the continuous beep thread
        beep_thread.join()

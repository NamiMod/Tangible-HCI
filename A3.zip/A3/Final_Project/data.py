from flask import Flask, render_template
import serial.tools.list_ports

app = Flask(__name__)

# Connect to serial port
ser = serial.Serial('/dev/cu.usbmodem141101', 9600)

@app.route('/')
def index():
    # Read data from serial port
    mood_value = ser.readline().decode('utf-8').strip()

    # Convert mood value to integer
    mood_value = int(mood_value)

    # Calculate background color based on mood value
    red_value = int(mood_value * 25.5)  # Adjust scale to fit 0-255 range
    background_color = f'rgb({255 - red_value}, 200, 200)'

    # Render template with background color
    return render_template('index.html', background_color=background_color)

if __name__ == '__main__':
    app.run(debug=True)
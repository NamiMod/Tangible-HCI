import serial.tools.list_ports
import pygame


def play_mp3(file_path):
    # Initialize pygame
    pygame.init()

    try:
        # Load the MP3 file
        pygame.mixer.music.load(file_path)

        # Play the MP3 file
        pygame.mixer.music.play()

        # Wait for the MP3 file to finish playing
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except pygame.error as e:
        print("Error playing MP3:", e)
    finally:
        # Quit pygame
        pygame.quit()


ser = serial.Serial('/dev/cu.usbmodem141101', 9600)

temp = -1

while True:
    anger_level = int(ser.readline().decode('utf-8').strip())
    if anger_level == 0 and anger_level != temp:
        print("-------------------------" + "\n")
        temp = anger_level

        print("It's good to be chill and enjoy life and the nice weather!" + "\n")

        print("-------------------------" + "\n")

    if 1 <= anger_level < 9 and anger_level != temp:
        temp = anger_level
        print("-------------------------" + "\n")

        print("Ok, Ok, chill, chill !" + "\n")

        print("-------------------------" + "\n")

    if anger_level == 9 and anger_level != temp:
        temp = anger_level
        print("-------------------------" + "\n")

        print("Chilllllll! eat chocolate !!!" + "\n")
        mp3_file = "damm.mp3"
        play_mp3(mp3_file)

        print("-------------------------" + "\n")
